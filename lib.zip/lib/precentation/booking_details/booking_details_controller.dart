import 'package:get/get.dart';

class BookingDetailsController extends GetxController {}