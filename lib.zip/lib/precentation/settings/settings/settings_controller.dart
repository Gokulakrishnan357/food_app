import 'package:get/get.dart';

import '../../../models/user_data_model.dart' show UserData;
import '../../../server/app_storage.dart';

class SettingsController extends GetxController {


}