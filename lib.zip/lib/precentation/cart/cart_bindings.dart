import 'package:get/get.dart';

class CartBindings implements Bindings {
  @override
  void dependencies() {}
}
