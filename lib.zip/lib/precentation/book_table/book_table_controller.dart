import 'package:get/get.dart';

class BookTableController extends GetxController {}