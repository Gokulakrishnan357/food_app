import 'package:get/get.dart';

class PaymentBindings implements Bindings {
  @override
  void dependencies() {
    // Get.put(PaymentController());
  }
}
