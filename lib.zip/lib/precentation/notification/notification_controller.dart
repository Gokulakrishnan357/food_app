import 'package:get/get.dart';

class NotificationController extends GetxController {}