import 'package:get/get.dart';

class AuthBindings implements Bindings {
  @override
  void dependencies() {}
}
