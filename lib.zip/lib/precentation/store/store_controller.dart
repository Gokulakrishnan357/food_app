import 'package:get/get.dart';

class StoreController extends GetxController {}