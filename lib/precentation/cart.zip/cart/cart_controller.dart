import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';
import 'package:zeroq/models/cart/local_cart.dart';
import 'package:zeroq/models/cart/local_cart_items.dart';
import 'package:zeroq/models/cart_models.dart';
import 'package:zeroq/precentation/auth/auth_controller.dart';
import 'package:zeroq/precentation/cart/cart_payment_controller.dart';
import 'package:zeroq/server/app_storage.dart';
import 'package:zeroq/server/network_handler.dart';
import 'package:http/http.dart' as http;
import '../../const/app_exports.dart';

class CartController extends GetxController {
  final CartPaymentController paymentController =
      Get.find<CartPaymentController>();

  final AuthController authController = Get.find<AuthController>();

  var cartItem = <ProductCart>[].obs;
  bool get isCartEmpty => cartItem.isEmpty;
  RxDouble totalPrices = 0.0.obs;
  RxInt quantity = 0.obs;
  RxInt subTotal = 0.obs;
  RxInt deleveryCharge = 200.obs;
  RxInt discountAmount = 0.obs;
  RxInt totalAmount = 0.obs;

  final ScrollController scrollController = ScrollController();
  var showBottomContainer = false.obs;
  var fabLocation = FloatingActionButtonLocation.centerDocked.obs;
  final AppNetworkHandler networkHandler = AppNetworkHandler();
  var getAllCart = FoodCartModel().obs;

// api maintaned cart details
  Rx<Cart?> cart = Rx<Cart?>(null);
  RxInt restaurantIdState = 0.obs;

  /// cart in local
  // List to store cart items
  RxList<CartItems> localCartItems = <CartItems>[].obs;

  @override
  Future<void> onInit() async {
    super.onInit();
    scrollController.addListener(_onScroll);

    fetchCartByUserId();
  }

  /// start api cart

  void fetchCartByUserId() async {
    try {
      final response = await GraphQLClientService.fetchData(
          query: GraphQuery.getCartByUserId(authController.userId.value));
      if (response.data!["cartByUserId"] != null) {
        Map<String, dynamic> jsonList = response.data!['cartByUserId'];

        Cart mappedCart = Cart.fromJson(jsonList);
        cart.value = mappedCart;
      }
    } catch (error) {
      //FIX : if api is error
      //When the cart is not avilable for the user id, etting -1 to cartId
      cart.value = Cart.emptyCart(-1);
      // Handle the error
      if (kDebugMode) {
        print('fetchCartById Error: $error');
      }
    }
  }

  Future<void> updateCartAPI(int cartId, int menuItemId, int quantity,
      double gstAmount, double discountAmount) async {
    try {
      if (cartId == -1) {
        return;
      }
      final response = await GraphQLClientService.fetchData(
          query: GraphQuery.updateCartDetails(
              cartId, menuItemId, quantity, gstAmount, discountAmount));
      if (response.data!["updateCartNew"] == null &&
          !response.data!["updateCartNew"]["success"]) {
        Get.snackbar("Error", response.data!["updateCart"]["message"]);
      } else {
        //apiFinal amount is wrong
        double apiFinalAmount =
            response.data!["updateCartNew"]["data"]["cart"]["finalAmount"] ?? 0;
        double totalcartValue = cart.value!.cartItems
            .fold(0.0, (sum, item) => sum + item.totalPrice);
        cart.value!.finalAmount = totalcartValue;
      }
    } catch (error) {
      if (kDebugMode) {
        print('Error: $error');
      }
    }
  }

  Future<void> createOrderGraphQL() async {
    try {
      try {
        final response = await GraphQLClientService.fetchData(
            query: GraphQuery.createOrder(
                cart.value!.cartId.toString(),
                "address",
                "cash",
                authController.userId.value
                    .toString())); //TODO : change the address, payment method
        if (response.data!["createOrder"] != null &&
            response.data!["createOrder"]["success"]) {
          await AmdStorage().createCache(
              'orderid',
              response.data!["createOrder"]["data"]["order"]["orderId"]
                  .toString());
          var orderId = await AmdStorage().readCache('orderid');
          paymentController.orderId.value = orderId; // 8
          paymentController.amount.value = cart.value!.finalAmount;
        }
      } catch (e) {
        if (kDebugMode) {
          print("Error : $e");
        }
        Get.snackbar(
          "Error",
          "Your Order got stuck somewhere",
          backgroundColor: AppColors.redColor,
          colorText: AppColors.whitetextColor,
          isDismissible: true,
        );

        return;
      }

      await handlePayment();
      paymentController.startPayment(
          paymentController.amount.value,
          paymentController.razorpayOrderId.value,
          "1234567890",
          "dev@zeroq.com",
          "mobDev");
      if (kDebugMode) {
        print("My order id is shown : ${paymentController.orderId.value}");
      }
    } catch (error) {
      if (kDebugMode) {
        print('Error: $error');
      }
    }
  }

  Future<void> handlePayment() async {
    try {
      final response = await GraphQLClientService.fetchData(
          query: GraphQuery.handlePayment(paymentController.amount.value,
              int.parse(paymentController.orderId.value)));
      if (response.data!["handlePayment"] != null) {
        paymentController.razorpayOrderId.value =
            response.data!["handlePayment"]["razorpayOrderId"].toString();
      }
    } catch (error) {
      if (kDebugMode) {
        print('Error: $error');
      }
    }
  }

  // void createOrder() async {
  //   paymentController.restorantId.value = cart.value!.restaurantId;
  //   final items = localCartItems
  //       .map((item) => {
  //             "menuId": item.menuId,
  //             "qty": item.quantity,
  //             "price": item.price,
  //             "offerApplied": 0, // Adjust this value as needed
  //             "offerAmount": 0 // Adjust this value as needed
  //           })
  //       .toList();
  //   final cartData = json.encode({
  //     "restaurantId": restaurantIdState.value, // Replace with actual values
  //     "restaurantMenuId": 0, // Replace with actual values
  //     "userId": 9, // Replace with actual values
  //     "quantity": totalQuantity, // Replace with actual values
  //     "itemsCount": localCartItems.length, // Replace with actual values
  //     "itemTotal": 0, //totalPrice, // Replace with actual values
  //     "platFormFee": 0, // Replace with actual values
  //     "gst": 0, // Replace with actual values
  //     "totalPay": 0, //totalPrice, // Replace with actual values
  //     "couponApplied": "0", // Replace with actual values
  //     "items": items,
  //   });

  //   try {
  //     final response = await networkHandler.post(
  //       ApiConfig.createOrderEndpoint,
  //       cartData,
  //     );
  //     if (kDebugMode) {
  //       print('Response: ${response.data}');
  //       print('Response: ${response.statusCode}');
  //     }
  //     if (response.statusCode == 200) {
  //       if (kDebugMode) {
  //         print(response.data['foodCartId']);
  //       }
  //       await AmdStorage()
  //           .createCache('orderid', response.data['foodCartId'].toString());
  //       var orderId = await AmdStorage().readCache('orderid');
  //       paymentController.orderId.value = orderId;
  //       if (kDebugMode) {
  //         print("My order id is shown : ${paymentController.orderId.value}");
  //       }
  //       // if (orderId != "") {}
  //       double totalprice = 0; //totalPrice * 100;
  //       createOrderId(totalprice, "", orderId, 9);
  //       paymentController.startPayment(
  //         totalprice,
  //         "",
  //         9894789477,
  //         "amdtechno@outlook.com",
  //         "Arun",
  //         // "0",
  //       );
  //     } else if (response.statusCode == 500) {}
  //   } catch (e) {
  //     if (kDebugMode) {
  //       print('Error: $e');
  //     }
  //   }
  // }

  void _onScroll() {
    final double maxScroll = scrollController.position.maxScrollExtent;
    final double currentScroll = scrollController.position.pixels;
    if (currentScroll == 0) {
      showBottomContainer.value = true;
      print("notscroll ${showBottomContainer.value}");
    } else if (currentScroll >= maxScroll) {
      showBottomContainer.value = false;
      print("currentScroll >= maxScroll ${showBottomContainer.value}");
    } else {
      showBottomContainer.value = false;
    }
  }

  Future<void> createNewCart(int restaurantId, int userId, CartItems itemToAdd,
      String restaurantName) async {
    try {
      final response = await GraphQLClientService.fetchData(
        query: GraphQuery.createCart(restaurantId, userId, itemToAdd),
      );
      if (response.data!["createCart"] != null &&
          response.data!["createCart"]["success"]) {
        int cartId = response.data!["createCart"]["data"]["cart"]["cartId"];

        cart.value = Cart(
          restaurantId: restaurantId,
          cartItems: [],
          discountAmount: itemToAdd.discountAmount,
          gstAmount: itemToAdd.gstAmount,
          restaurantName: restaurantName,
          cartId: cartId,
          createdAt: DateTime.now(),
          finalAmount: itemToAdd.totalPrice,
          itemTotal: 1,
          serviceCharge: 0,
          packagingCharges: 0,
          status: "active",
          updatedAt: DateTime.now(),
          userId: userId.toInt(),
        );
        cart.value!.cartItems.add(itemToAdd);

        cart.refresh();
      }
    } catch (error) {
      if (kDebugMode) {
        print('Error: $error');
      }
    }
  }

  Future<void> deleteCart(int cartId) async {
    try {
      if (cartId == -1) return;
      final response = await GraphQLClientService.fetchData(
          query: GraphQuery.deleteCart(cartId));
      if (response.data!["deleteCart"]["success"]) {
        cart.value = Cart.emptyCart(-1);
      }
    } catch (error) {
      if (kDebugMode) {
        print('Error: $error');
      }
    }
  }

  /// start of local cart items.
  void addToCart(
      int menuId,
      int restaurantId,
      String menuName,
      menuDescription,
      menuImage,
      dynamic price,
      int qty,
      double discountAmount,
      double gstAmount,
      String imageUrl,
      String restaurantName) async {
    List<CartItems> localCartItemsGraph = cart.value?.cartItems ?? [];
    //When cart is not available and cartItems is empty, Create new cart
    if (cart.value?.cartId == -1 && cart.value?.cartItems.isEmpty == true) {
      CartItems itemToAdd = CartItems(
        menuId: menuId,
        restaurantId: restaurantId,
        menuName: menuName,
        menuDescription: menuDescription,
        imageUrl: imageUrl,
        price: price,
        quantity: qty,
        discountAmount: discountAmount,
        gstAmount: gstAmount,
        totalPrice: price * qty + gstAmount,
      );
      await createNewCart(
          restaurantId, authController.userId.value, itemToAdd, restaurantName);

      return;
    }
    //when cart is available, check if the item is already in the cart
    int existingIndex =
        localCartItemsGraph.indexWhere((item) => item.menuId == menuId);

    // Check if the item already exists in the cart

    if (existingIndex != -1) {
      int revisedQty = localCartItemsGraph[existingIndex].quantity + qty;
      localCartItemsGraph[existingIndex] = CartItems(
        discountAmount: discountAmount,
        gstAmount: gstAmount,
        totalPrice: revisedQty * price + gstAmount,
        menuId: menuId,
        menuName: menuName,
        quantity: revisedQty,
        price: price,
        restaurantId: restaurantId,
        menuDescription: menuDescription,
        imageUrl: imageUrl,
      );
      await updateCartAPI(cart.value!.cartId ?? -1, menuId, revisedQty,
          gstAmount, discountAmount);
    } else {
      //add new itme from another restaurant
      bool isSameRestaurantGraph = localCartItemsGraph.isEmpty ||
          cart.value?.restaurantId == restaurantId;

      if (!isSameRestaurantGraph) {
        // If the new item is from a different restaurant,local cart is not empty,
        // clear the cart
        Get.dialog(
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                child: Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.all(
                      Radius.circular(20),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Material(
                      child: Column(
                        children: [
                          const SizedBox(height: 10),
                          const Text(
                            "Replace Cart item",
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 15),
                          const Text(
                            "Your Cart contains dishes from Another Restaurants, Do you want to discard the selection and add dishes.",
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 20),
                          //Buttons
                          Row(
                            children: [
                              Expanded(
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    minimumSize: const Size(0, 45),
                                    backgroundColor: Colors.amber,
                                    // onPrimary: const Color(0xFFFFFFFF),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  onPressed: () {
                                    Get.back();
                                  },
                                  child: const Text(
                                    'NO',
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    minimumSize: const Size(0, 45),
                                    backgroundColor: Colors.amber,
                                    // onPrimary: const Color(0xFFFFFFFF),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  onPressed: () async {
                                    // If the new item is from a different restaurant,
                                    //delete the cart from API
                                    await deleteCart(cart.value!.cartId ?? -1);

                                    //creating cart Items entity
                                    CartItems itemToAdd = CartItems(
                                      menuId: menuId,
                                      restaurantId: restaurantId,
                                      menuName: menuName,
                                      menuDescription: menuDescription,
                                      imageUrl: imageUrl,
                                      price: price,
                                      quantity: qty,
                                      discountAmount: discountAmount,
                                      gstAmount: gstAmount,
                                      totalPrice: price * qty + gstAmount,
                                    );
                                    // Create new cart with new items
                                    await createNewCart(
                                        restaurantId,
                                        authController.userId.value,
                                        itemToAdd,
                                        restaurantName);
                                    Get.back();
                                  },
                                  child: const Text(
                                    'YES',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      } else {
        //If the new item is from a same restaurant, add in the existing cart
        localCartItemsGraph.add(CartItems(
          menuId: menuId,
          restaurantId: restaurantId,
          menuName: menuName,
          menuDescription: menuDescription,
          imageUrl: imageUrl,
          price: price,
          quantity: qty,
          discountAmount: discountAmount,
          gstAmount: gstAmount,
          totalPrice: qty * price + gstAmount,
        ));
        updateCartAPI(
            cart.value!.cartId ?? -1, menuId, qty, gstAmount, discountAmount);
        double revisedCartPrice = 0.0;
        for (var element in localCartItemsGraph) {
          revisedCartPrice += element.totalPrice;
        }
        Cart? updatedCart = cart.value;
        updatedCart?.finalAmount = revisedCartPrice;
        cart.value = updatedCart;
        cart.refresh();
      }
    }
  }

  void calculateFinalCartPrice() {
    double revisedCartPrice = 0.0;
    for (var element in cart.value!.cartItems) {
      revisedCartPrice += element.totalPrice;
    }
    cart.value!.finalAmount = revisedCartPrice;
    cart.refresh();
  }

  void increaseQuantity(CartItems item, int quantityToAdd) async {
    int index = cart.value!.cartItems.indexOf(item);
    CartItems cartItem = cart.value!.cartItems[index];
    int revisedQuantity = item.quantity + quantityToAdd;
    double revisedPrice = (item.price * revisedQuantity) + item.gstAmount;
    if (index != -1) {
      cart.value!.cartItems[index] = CartItems(
        menuId: item.menuId,
        restaurantId: item.restaurantId,
        menuName: item.menuName,
        menuDescription: item.menuDescription,
        imageUrl: item.imageUrl,
        price: item.price,
        quantity: revisedQuantity,
        discountAmount: item.discountAmount,
        gstAmount: item.gstAmount,
        totalPrice: revisedPrice,
      );
      calculateFinalCartPrice();
      await updateCartAPI(cart.value!.cartId ?? -1, item.menuId,
          revisedQuantity, item.gstAmount, item.discountAmount);
      cart.refresh();
    }
  }

  void decreaseQuantity(CartItems item, int quantityToRemove) async {
    int index = cart.value?.cartItems.indexOf(item) ?? -1;

    if (index != -1) {
      int newQuantity = item.quantity - quantityToRemove;
      double newPrice = (item.price * newQuantity) + item.gstAmount;
      if (newQuantity > 0) {
        // Update the item with the new quantity
        cart.value?.cartItems[index] = CartItems(
          menuId: item.menuId,
          restaurantId: item.restaurantId,
          menuName: item.menuName,
          menuDescription: item.menuDescription,
          imageUrl: item.imageUrl,
          price: item.price,
          quantity: newQuantity,
          discountAmount: item.discountAmount,
          gstAmount: item.gstAmount,
          totalPrice: newPrice,
        );
        var revisedFinalAmount = quantityToRemove * item.price + item.gstAmount;
        cart.value!.finalAmount -=
            revisedFinalAmount > 0 ? revisedFinalAmount : 0;

        await updateCartAPI(cart.value!.cartId ?? -1, item.menuId, newQuantity,
            item.gstAmount, item.discountAmount);
        cart.refresh();
      } else {
        // Remove the item from the cart if the new quantity is 0 or less
        cart.value!.finalAmount -= item.totalPrice;
        cart.value!.cartItems.remove(item);
        await updateCartAPI(cart.value!.cartId ?? -1, item.menuId, 0,
            item.gstAmount, item.discountAmount);

        cart.refresh();
        if (cart.value!.cartItems.isEmpty) {
          await deleteCart(cart.value!.cartId ?? -1);
        }
      }
    }
  }

  void removeFromCart(CartItems item) {
    QuickAlert.show(
      context: Get.context!,
      type: QuickAlertType.warning,
      text: 'Confirm Remove the ${item.menuName}!',
      onConfirmBtnTap: () {
        cart.value!.finalAmount -= item.totalPrice;
        cart.value!.cartItems.remove(item);
        cart.refresh();
        if (cart.value!.cartItems.isEmpty) {
          deleteCart(cart.value!.cartId ?? -1);
        }

        Get.back();
      },
      onCancelBtnTap: () {
        Get.back();
      },
      headerBackgroundColor: AppColors.greenColor,
    );
  }

  int get totalItems => cart.value?.cartItems.length ?? 0;

  // Calculate total quantity
  int get totalQuantity {
    return cart.value?.cartItems.fold(0, (sum, item) => sum! + item.quantity) ??
        0;
  }

  double get totalCartPrice =>
      cart.value?.cartItems.fold(
          0, (total, current) => total! + (current.price * current.quantity)) ??
      0;

  /// end of spi cart
  ///
  /// create the order using razorpay
  void createRazorPayOrder() {}

  createOrderId(amount, description, id, userId) async {
    http.Response response = await http.post(
        Uri.parse(
          "https://api.razorpay.com/v1/orders",
        ),
        headers: {
          "Content-Type": "application/json",
          "Authorization":
              "Basic ${base64Encode(utf8.encode('rzp_test_sqlgh4Ta7LYOqu'))} "
        },
        body: json.encode({
          "amount": amount,
          "currency": "INR",
          "receipt": "OrderId_$id",
          "notes": {"userId": "$userId", "packageId": "$id"},
        }));
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
    }
    print("Razorpay order id = ${response.body}");
  }
}
