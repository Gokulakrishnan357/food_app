import 'package:quickalert/models/quickalert_type.dart';
import 'package:quickalert/widgets/quickalert_dialog.dart';
import 'package:zeroq/precentation/cart/cart_payment_controller.dart';
import 'package:zeroq/precentation/pick_up/components/hotel_menu/hotel_menu_controller.dart';
import 'package:zeroq/server/app_storage.dart';

import '../../const/app_exports.dart';
import './cart_controller.dart';

class CartPage extends GetView<CartController> {
  CartPage({super.key});

  final hotalMenuController = Get.find<HotelMenuController>();
  final CartPaymentController cartPaymentController =
      Get.find<CartPaymentController>();

  void addItems() async {

    hotalMenuController.restaurantId.value =
        controller.cart.value!.restaurantId.toString();
    await hotalMenuController.fetchRestaurantsMenuByIdFromGraph();
    await hotalMenuController.fetchRestaurantsByIdFromGraph();

    Future.delayed(
      const Duration(milliseconds: 500),
      () {
        Get.toNamed(
          AmdRoutesClass.hotelMenuPage,
        );
      },
    );


  }

  @override
  Widget build(BuildContext context) {
    ScreenUtil.init(
      context,
      designSize: const Size(
        375,
        812,
      ),
    );
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Get.back(),
          icon: const Icon(
            FontAwesomeIcons.arrowLeft,
            color: AppColors.greenColor,
          ),
        ),
        title: AmdText(
          text: 'CartPage',
          color: AppColors.blackColor,
          height: 0.8,
          size: 17.0.sp,
          weight: FontWeight.w400,
        ),
      ),
      body: SizedBox(
        width: 375.0.w,
        height: 812.0.w,
        child: Stack(
          children: [

            Positioned(
              left: 10.0.w,
              right: 10.0.w,
              child: Container(
                width: 360.0.w,
                constraints: BoxConstraints(maxHeight: 410.0.w), // Add constraints
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20.0.w),
                  color: Colors.white,
                ),
                child: Obx(() {
                  return controller.cart.value!.cartItems.isNotEmpty
                      ? Column(
                    children: [
                      Expanded(
                        child: ListView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(), // Prevent internal scrolling
                          itemCount: controller.cart.value?.cartItems.length,
                          itemBuilder: (context, index) {
                            var product = controller.cart.value!.cartItems[index];

                            return Column(
                              children: [
                                Padding(
                                  padding: EdgeInsets.only(bottom: 10.0.w),
                                  child: Container(
                                    width: 327.0.w,
                                    height: 90.0.w,
                                    padding: EdgeInsets.all(12.0.w),
                                    decoration: ShapeDecoration(
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(16.0.w),
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        // Top Row: Menu Name and Price
                                        Row(
                                          mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                          children: [
                                            Row(
                                              children: [
                                                Container(
                                                  width: 15.0.w,
                                                  height: 25.0.w,
                                                  decoration: const BoxDecoration(
                                                    image: DecorationImage(
                                                      image: AssetImage("assets/icons/nonVeg.png"),
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(width: 5.0.w),
                                                // Ensuring text doesn't overflow
                                                Expanded(
                                                  child: AmdText(
                                                    text: product.menuName,
                                                    size: 18,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(width: 10.0.w),
                                            AmdText(
                                              text: "₹ ${product.totalPrice}",
                                              size: 18,
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: 10.0.w),

                                        // Middle Row: Customizable Label and Quantity Controls
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            // Ensuring the description does not cause overflow
                                            Expanded(
                                              child: AmdText(
                                                text: product.menuDescription.isNotEmpty
                                                    ? product.menuDescription
                                                    : "Not available",
                                                size: 12,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                            SizedBox(width: 10.0.w),

                                            // Quantity Controls
                                            Row(
                                              children: [
                                                InkWell(
                                                  onTap: () {
                                                    controller.decreaseQuantity(product, 1);
                                                  },
                                                  child: Container(
                                                    width: 22.0.w,
                                                    height: 22.0.w,
                                                    decoration: ShapeDecoration(
                                                      color: AppColors.textFieldLabelColor.withOpacity(0.26),
                                                      shape: const OvalBorder(),
                                                    ),
                                                    child: Icon(
                                                      FontAwesomeIcons.minus,
                                                      color: AppColors.blackColor,
                                                      size: 16.0.sp,
                                                    ),
                                                  ),
                                                ),

                                                SizedBox(width: 5.0.w),
                                                SizedBox(
                                                  width: 35.0.w,
                                                  child: Center(
                                                    child: AmdText(
                                                      text: '${product.quantity}',
                                                      size: 16.0.sp,
                                                      color: AppColors.blackColor,
                                                      textAlign: TextAlign.center,
                                                      weight: FontWeight.w700,
                                                    ),
                                                  ),
                                                ),
                                                SizedBox(width: 5.0.w),
                                                InkWell(
                                                  onTap: () {
                                                    controller.increaseQuantity(product, 1);
                                                  },
                                                  child: Container(
                                                    width: 22.0.w,
                                                    height: 22.0.w,
                                                    decoration: ShapeDecoration(
                                                      color: AppColors.textFieldLabelColor.withOpacity(0.26),
                                                      shape: const OvalBorder(),
                                                    ),
                                                    child: Icon(
                                                      FontAwesomeIcons.plus,
                                                      color: AppColors.blackColor,
                                                      size: 16.0.sp,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                const Divider(
                                  color: Color(0xFFD3D3D3),
                                  thickness: 2.0,
                                  height: .25,
                                  indent: 16.0,
                                  endIndent: 16.0,
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                      TextButton(
                        onPressed: addItems,
                        style: ButtonStyle(
                          foregroundColor: WidgetStateProperty.all(AppColors.greenColor),
                        ),
                        child: const Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.add, color: AppColors.greenColor),
                            SizedBox(width: 4),
                            Text("Add Item")
                          ],
                        ),
                      )
                    ],
                  )
                      : Column(
                    children: [
                      Image.asset("assets/icons/emptycart1.png"),
                      AmdButton(
                        press: () {
                          Get.offNamed(AmdRoutesClass.pickUpPage);
                        },
                        size: Size(200.0.w, 50.0.w),
                        buttoncolor: AppColors.greenColor,
                        child: const AmdText(
                          text: "Browse Restaurants",
                          color: AppColors.whitetextColor,
                        ),
                      ),
                    ],
                  );
                }),
              ),
            ),

            Positioned(
              bottom: 0.0.w,
              child: Container(
                width: 380.0.w,
                height: 284.0.w,
                padding: EdgeInsets.all(24.0.w),
                decoration: ShapeDecoration(
                  color: AppColors.greenColor,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(
                        24.0.w,
                      ),
                      topRight: Radius.circular(
                        24.0.w,
                      ),
                    ),
                  ),
                  shadows: const [
                    BoxShadow(
                      color: Color(0x145A6CEA),
                      blurRadius: 50,
                      offset: Offset(12, 26),
                      spreadRadius: 0,
                    )
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 24.0.w,
                      child: SizedBox(
                        width: 332.0.w,
                        height: 30.0.w,
                        child: Stack(
                          children: [
                            Positioned(
                              child: SizedBox(
                                width: 100.0.w,
                                child: AmdText(
                                  text: 'Subtotal',
                                  color: AppColors.whitetextColor,
                                  size: 16.0.sp,
                                  weight: FontWeight.w400,
                                ),
                              ),
                            ),
                            Positioned(
                              right: 0.0.w,
                              child: SizedBox(
                                height: 24.0.w,
                                width: 150.0.w,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    right: 5.0.w,
                                  ),
                                  child: Obx(() {
                                    // var stringWithParentheses = controller
                                    //     .cartItems
                                    //     .map((element) =>
                                    //         element.price *
                                    //         controller.quantity.value)
                                    //     .toString();

                                    // String cleanedString = stringWithParentheses
                                    //     .replaceAll(RegExp(r'[()]'), '');

                                    return controller.totalCartPrice != 0
                                        ? AmdText(
                                            text:
                                                '₹ ${controller.totalCartPrice}',
                                            textAlign: TextAlign.right,
                                            color: AppColors.whitetextColor,
                                            size: 20.0.sp,
                                            weight: FontWeight.w400,
                                          )
                                        : AmdText(
                                            text:
                                                '₹ ${controller.totalCartPrice}',
                                            textAlign: TextAlign.right,
                                            color: AppColors.whitetextColor,
                                            size: 20.0.sp,
                                            weight: FontWeight.w400,
                                          );
                                  }),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      top: 62.0.w,
                      child: SizedBox(
                        width: 332.0.w,
                        height: 30.0.w,
                        child: Stack(
                          children: [
                            Positioned(
                              child: SizedBox(
                                width: 130.0.w,
                                child: AmdText(
                                  text: 'Delivery charge',
                                  color: AppColors.whitetextColor,
                                  size: 16.0.sp,
                                  weight: FontWeight.w400,
                                ),
                              ),
                            ),
                            Positioned(
                              right: 0.0.w,
                              child: SizedBox(
                                height: 24.0.w,
                                width: 150.0.w,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    right: 5.0.w,
                                  ),
                                  child: Obx(
                                    () => AmdText(
                                      text: controller.subTotal.value != 0 &&
                                              controller
                                                  .localCartItems.isNotEmpty
                                          ? '₹ ${controller.deleveryCharge.value}'
                                          : '₹ 0',
                                      textAlign: TextAlign.right,
                                      color: AppColors.whitetextColor,
                                      size: 20.0.sp,
                                      weight: FontWeight.w400,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      top: 138.0.w,
                      child: SizedBox(
                        width: 332.0.w,
                        child: Divider(
                          color: AppColors.whitetextColor,
                          height: 2.0.w,
                        ),
                      ),
                    ),
                    Positioned(
                      top: 146.0.w,
                      child: SizedBox(
                        width: 332.0.w,
                        height: 30.0.w,
                        child: Stack(
                          children: [
                            Positioned(
                              child: SizedBox(
                                width: 100.0.w,
                                child: AmdText(
                                  text: 'Total',
                                  color: AppColors.whitetextColor,
                                  size: 16.0.sp,
                                  weight: FontWeight.w400,
                                ),
                              ),
                            ),
                            Positioned(
                              right: 0.0.w,
                              child: SizedBox(
                                height: 24.0.w,
                                width: 150.0.w,
                                child: Padding(
                                  padding: EdgeInsets.only(
                                    right: 5.0.w,
                                  ),
                                  child: Obx(() {
                                    return AmdText(
                                      text: controller
                                                  .cart.value?.finalAmount !=
                                              0
                                          ? '₹ ${controller.cart.value!.finalAmount}'
                                          : '₹ 0',
                                      textAlign: TextAlign.right,
                                      color: AppColors.whitetextColor,
                                      size: 20.0.sp,
                                      weight: FontWeight.w400,
                                    );
                                  }),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 0.0.w,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(45.0.w),
                        child: SizedBox(
                          width: 327.0.w,
                          height: 41.0.w,
                          // color: AppColors.whitetextColor,
                          // padding: EdgeInsets.only(left: 24.0.w),
                          child: AmdButton(
                            press: controller.cart.value!.cartItems.isNotEmpty
                                ? () async {
                                    var userId =
                                        await AmdStorage().readCache('userId');

                                    print("My userId is $userId");

                                    if (userId != "" && userId != null) {
                                      controller.createOrderGraphQL();
                                    } else {
                                      await QuickAlert.show(
                                        context: Get.context!,
                                        type: QuickAlertType.warning,
                                        text: 'Plz Register / SignIn!',
                                        onConfirmBtnTap: () {
                                          Get.back();
                                          Get.toNamed(AmdRoutesClass.authPage);
                                        },
                                        headerBackgroundColor:
                                            AppColors.greenColor,
                                      );
                                    }
                                  }
                                : null,
                            size: Size(
                              327.0.w,
                              42.0.w,
                            ),
                            buttoncolor:
                                controller.cart.value!.cartItems.isEmpty
                                    ? AppColors.headingtextColor
                                    : AppColors.whitetextColor,
                            radius: 45.0.w,
                            child: AmdText(
                              text: "Continue",
                              color: controller.cart.value!.cartItems.isNotEmpty
                                  ? AppColors.greenColor
                                  : AppColors.headingtextColor,
                              size: 14.0.sp,
                              weight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Obx(
              () {
                if (cartPaymentController.isLoading.value) {
                  return Positioned.fill(
                    child: Container(
                      color: Colors.black
                          .withOpacity(0.5), // Semi-transparent overlay
                      child: const Center(
                        child: CircularProgressIndicator(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  );
                }
                return const SizedBox.shrink(); // Invisible when not loading
              },
            ),
          ],
        ),
      ),
    );
  }
}
